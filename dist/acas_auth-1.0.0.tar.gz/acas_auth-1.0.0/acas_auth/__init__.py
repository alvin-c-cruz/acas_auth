from . import application
from .application import create_app
from .application.extensions import installed_apps
